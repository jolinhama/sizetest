// Required javascript files
//  lookupManager.js
var CMSUtility = {
    getAnchorID: function(tabID) {
        return "tab_control_tab_" + tabID;
    },
    getTabIDFromAnchor: function(node) {
        if (node != null && node.id != null) {
            var lastIndex = node.id.lastIndexOf("_");
            if (lastIndex >= 0) {
                return node.id.substring(lastIndex + 1);
            }
        }
        return null;
    },
    getTabIDFromAnchorID: function(node) {
        if (node != null && node.length > 0) {
            var lastIndex = node.lastIndexOf("_");
            if (lastIndex >= 0) {
                return node.substring(lastIndex + 1);
            }
        }
        return null;
    },
    // dateFormat can include yyyy mm dd hh MM ss pattern and these pattern will be replaced by real values.
    // yyyy - 4 digit year, mm - month, dd - day, HH - 24 hours, hh - 12hours, MM - minutes, ss - seconds, a - AM/PM
    formatDateString: function(dateFormat, yyyy, mm, dd, hh, MM, ss) {
        if (dateFormat == null || dateFormat.length == 0) {
            dateFormat = "mm/dd/yyyy";
        }
        var dateString = dateFormat;
        if (yyyy != null && yyyy.length > 0) {
            dateString = dateString.replace(/yyyy/, yyyy);
        }
        if (mm != null && mm.length > 0) {
            dateString = dateString.replace(/mm/, mm);
        }
        if (dd != null && dd.length > 0) {
            dateString = dateString.replace(/dd/, dd);
        }
        if (hh != null && hh.length > 0) {
            var amPM = 'AM';
            dateString = dateString.replace(/HH/, hh);

            var hh12 = hh;
            if (hh12 >= 12) {
                amPM = 'PM';
                hh12 = (hh12 > 12) ? (hh12 - 12) : hh12;
                hh12 = '' + hh12;
                hh12 = (hh12.length == 1) ? ('0' + hh12) : hh12;
            }
            dateString = dateString.replace(/hh/, hh12);
            dateString = dateString.replace(/a/, amPM);
        }

        if (MM != null && MM.length > 0) {
            dateString = dateString.replace(/MM/, MM);
        }
        if (ss != null && ss.length > 0) {
            dateString = dateString.replace(/ss/, ss);
        }

        dateString = dateString.replace(/yyyy/, '');
        dateString = dateString.replace(/mm/, '');
        dateString = dateString.replace(/dd/, '');
        dateString = dateString.replace(/hh/, '');
        dateString = dateString.replace(/MM/, '');
        dateString = dateString.replace(/ss/, '');

        return dateString;
    },
    //
    // option : {
    //     isUTC: true // true or false
    //     dateFormat: "yyyy/mm/dd"    // The patterns yyyy mm dd hh MM ss can will be replaced with real values.
    // }
    //
    getDateString: function(option, when) {
        var year, month, day, hours, minutes, seconds;
        if (option.isUTC == true) {
            year = when.getUTCFullYear();
            month = when.getUTCMonth() + 1;
            day = when.getUTCDate();
            hours = when.getUTCHours();
            minutes = when.getUTCMinutes();
            seconds = when.getUTCSeconds();
        } else {
            year = when.getFullYear();
            month = when.getMonth() + 1;
            day = when.getDate();
            hours = when.getHours();
            minutes = when.getMinutes();
            seconds = when.getSeconds();
        }

        if (month < 10) {
            month = "0" + month;
        }
        if (day < 10) {
            day = "0" + day;
        }
        if (hours < 10) {
            hours = "0" + hours;
        }
        if (minutes < 10) {
            minutes = "0" + minutes;
        }
        if (seconds < 10) {
            seconds = "0" + seconds;
        }
        year = "" + year;
        month = "" + month;
        day = "" + day;
        hours = "" + hours;
        minutes = "" + minutes;
        seconds = "" + seconds;

        return this.formatDateString(option.dateFormat, year, month, day, hours, minutes, seconds);
    },
    getNowUTCString: function() {
        var now = new Date();
        return this.getDateString({isUTC: true, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
    },
    // The parameter "components" is array of component IDs.
    enableComponents: function(components) {
        if (components != null && components.length > 0) {
            components.forEach(function(component) {
                hyf.util.enableComponent(component);
            });
        }
    },
    // The parameter "components" is array of component IDs.
    disableComponents: function(components) {
        if (components != null && components.length > 0) {
            components.forEach(function(component) {
                hyf.util.disableComponent(component);
            });
        }
    },
    restoreBizFlowParameter: function() {
        var sessionInfo = $('#sessioninfo').attr('value');
        if (sessionInfo != null && sessionInfo.length > 0) {         // Backup
            $('#sessioninfo2').attr('value', $('#sessioninfo').attr('value'));
            $('#procid2').attr('value', $('#procid').attr('value'));
            $('#actseq2').attr('value', $('#actseq').attr('value'));
            $('#workseq2').attr('value', $('#workseq').attr('value'));
            $('#appseq2').attr('value', $('#appseq').attr('value'));
            $('#isarchive2').attr('value', $('#isarchive').attr('value'));
            $('#readOnly2').attr('value', $('#readOnly').attr('value'));
        } else { // Restore
            $('#sessioninfo').attr('value', $('#sessioninfo2').attr('value'));
            $('#procid').attr('value', $('#procid2').attr('value'));
            $('#actseq').attr('value', $('#actseq2').attr('value'));
            $('#workseq').attr('value', $('#workseq2').attr('value'));
            $('#appseq').attr('value', $('#appseq2').attr('value'));
            $('#isarchive').attr('value', $('#isarchive2').attr('value'));
            $('#readOnly').attr('value', $('#readOnly2').attr('value'));
        }
    }
};

var BFActivityOption = {
    _activityName: null,
    _currentActivity: null,
    _currentTabs: null,

    getCurrentActivityOption: function(activityName) {
        if (activityName != this._activityName) {
            this._currentActivity = null;
            this._currentTabs = null;
            this._activityName = activityName;
        }

        if (this._currentActivity == null) {
            if (activityName == null || activityName.length == 0) {
                activityName = "_Archive_";
            }

            // Find current activity name and tab information associated with current activity name
            var currentActList = [];
            currentActList = BFActivityOption.actList.filter(function(node, index) {
                var memberCount = 0;
                if (node.usergroup.length > 0) {
                    node.usergroup.forEach(function(group) {
                        if (isCurrentUserMemberOf(group) == true) {
                            memberCount++;
                        }
                    })
                }
                return node.name == activityName && (memberCount == node.usergroup.length || memberCount > 0);
            });
            // If current activity is not in the BFActivityOption, add _Archive_ configuration
            if (currentActList.length == 0) {
                currentActList.push(BFActivityOption.actList[BFActivityOption.actList.length - 1]);
            }
            this._currentActivity = currentActList[0];
            this._currentTabs = this._currentActivity.tabs.slice();
        }
        return this._currentActivity;
    },
    getActiveTabList: function(activityName) {
        if (this._currentTabs == null) {
            var activityOption = this.getCurrentActivityOption(activityName);
        }
        return this._currentTabs;
    },
    addTabToCurrentActivity: function(activityName, tabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == tabID) {
                    return; // Already exists.
                }
            }
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] > tabID) {
                    this._currentTabs.splice(index, 0, tabID);
                    break;
                }
            }
        }
    },
    removeTabFromCurrentActivity: function(activityName, tabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == tabID) {
                    this._currentTabs.splice(index, 1);
                    break;
                }
            }
        }
    },

    // addTabToCurrentActivity: function(activityName, tabID) {
    //     if (this._currentTabs != null) {
    //         var foundTabs = this._currentTabs.filter(function(tab, index) {
    //             return tab == tabID;
    //         });
    //
    //         console.log('BEFORE - _currentTabs [' + this._currentTabs.join() + ']');
    //
    //         if (foundTabs.length == 0) {
    //             var added = false;
    //             for (var index = 0; index < this._currentTabs.length; index++) {
    //                 if (this._currentTabs[index] > tabID) {
    //                     this._currentTabs.splice(index, 0, tabID);
    //                     added = true;
    //                     break;
    //                 }
    //             }
    //             if (added == false) {
    //                 this._currentTabs.push(tabID);
    //             }
    //             console.log('AFTER - _currentTabs [' + this._currentTabs.join() + ']');
    //         } else {
    //             console.log('Tab [' + tabID + '] exists in _currentTabs.');
    //         }
    //     }
    // },

    getCurrentTabID: function() {
        var currentTabs = $('#tab_control_container a.selectedTab');
        var tabCount = currentTabs.length;

        if (currentTabs.length > 0) {
            var tabAnchorID = currentTabs[0].attributes["id"].value;
            var tabID = CMSUtility.getTabIDFromAnchorID(tabAnchorID);
            return tabID;
        }
        return null;
    },
    getNextTabID: function(currentTabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == currentTabID) {
                    if (index < this._currentTabs.length - 1) {
                        return this._currentTabs[index + 1];
                    }
                }
            }
        }
        return null;
    },
    getPreviousTabID: function(currentTabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == currentTabID) {
                    if (index > 0) {
                        return this._currentTabs[index - 1];
                    }
                }
            }
        }
        return null;
    },
    actList: [{
            name: "Create Request",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab9"],
            readonly: []
        },{
            name: "Review Request",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab9"],
            readonly: []
        }, {
            name: "Modify Request",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab9"],
            readonly: []
        }, {
            name: "Hold Strategic Consultation Meeting",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"],
            readonly: []
        }, {
            name: "Acknowledge Strat Cons Meeting",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
            readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"]
        }, {
            name: "Approve Strat Cons Meeting",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
            readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9"]
        }, {
            name: "_Archive_",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"],
            readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9"]
        }
    ]
};

// Caution: Clear dependency is important.
// TabManager can call BFActivityOption, but BFActivityOption cannot call TabManager.
var TabManager = {
    totalLoadedTabCount: 0,
    getTab: function(tabID) {
        var selectedTabs = this.tabList.filter(function(node, index) {
            return node.id == tabID;
        });
        var foundTab = null;
        if (selectedTabs.length == 1) {
            foundTab = selectedTabs[0];
        }
        return foundTab;
    },
    loadTabFromAnchor: function(node) {
        var currentTabID = BFActivityOption.getCurrentTabID();
        var tabID = CMSUtility.getTabIDFromAnchor(node);
        var tab = this.getTab(tabID);

        if (tab.disabledHeader == false) {
            if (tabID == 'tab9' || TabManager.isTabCompleted(currentTabID) == true) {
                this.loadTab(tabID);
            } else {
                console.log("STRATCONMAIN - TabManager.loadTabFromAnchor() - current tab is not completed. Canceled tab-change-request!");
            }
        }
        // Tab click on disabled tab should be ignored.
    },
    loadTab: function(tabID) {
        var selectedTab = this.getTab(tabID)
        if (selectedTab != null) {
            if (selectedTab.loaded == false) {
                callPartialPage(null, selectedTab.targetUrl, "system", selectedTab.targetGroup);
                selectedTab.loaded = true;
            }
        }
    },
    showTabHeader: function(tabID) {
        if ($('#' + CMSUtility.getAnchorID(tabID) + ':hidden').length > 0) {
            hyf.util.showComponent("tab_control_tab_" + tabID, null, null, null);
        }
    },
    hideTabHeader: function(tabID) {
        if ($('#' + CMSUtility.getAnchorID(tabID) + ':visible').length > 0) {
            hyf.util.hideComponent("tab_control_tab_" + tabID, null, null, null);
        }
    },
    enableTab: function(tabID) {
        hyf.util.enableComponent(tabID);
        $('#' + tabID + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').show();

        if (tabID == 'tab8') {
            stratconApr_rollbackHandler();
        }
    },

    disableTab: function(tabID) {
        hyf.util.disableComponent(tabID);
        $('#' + tabID + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').hide();
    },

    clearTabContent: function(tabID) {
        $.each($('#' + tabID + ' input.checkbox'), function(component) {
            var value = $(this).prop('checked');
            if (value == true) {
                $(this).prop('checked', false);
                $(this).trigger('change');
            }
        });
        $.each($('#' + tabID + ' input.textbox'), function(component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
            }
        });

        // For Outreach tab
        $.each($('#' + tabID + ' input[type=checkbox]'), function(component) {
            $(this).prop('checked', false);
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).trigger('change');
            }
        });

        $.each($('#' + tabID + ' select'), function(component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
                $(this).trigger('change');
            }
        });
        $.each($('#' + tabID + ' textarea'), function(component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
            }
        });

        if (tabID == 'tab6') {
            $('#RI_OA_APRV_ITEM').val('NA');
        }
    },
    enableTabHeader: function(tabID) {
        var tab = this.getTab(tabID);
        if (tab != null) {
            tab.disabledHeader = false;
            var anchorID = CMSUtility.getAnchorID(tabID);
            $('#' + anchorID).removeClass('disabledTab');
            $('#' + anchorID).addClass('unselectedTab');
        } else {
            console.log("STRATCONMAIN - TabManager.enableTabHeader() - tabID is null");
        }
    },
    disableTabHeader: function(tabID) {
        var tab = this.getTab(tabID);
        if (tab != null) {
            tab.disabledHeader = true;
            var anchorID = CMSUtility.getAnchorID(tabID);
            $('#' + anchorID).removeClass('unselectedTab');
            $('#' + anchorID).addClass('disabledTab');
        } else {
            console.log("STRATCONMAIN - TabManager.disabledTabHeader() - tabID is null");
        }
    },
    allPreviousTabCompleted: function(tabID) {
        for (var index = 0; index < this.tabList.length; index++) {
            if (this.tabList[index].id == tabID) {
                break;
            }
            if (this.tabList[index].completed == false) {
                return false;
            }
        }
        return true;
    },
    validateTab: function(tabID) {
        if (isReadOnly() == false) {
            var validationResultTab7 = true;
            var validationResultTab2 = true;
            var validationResult = hyf.validation.validateContainer(document.getElementById(tabID));
            if (tabID == 'tab7') {
                validationResultTab7 = validateStratconTrCustom();
            }
            if (tabID == 'tab2') {
                validationResultTab2 = validateStratconPOSCustom();
            }

            return validationResult && validationResultTab2 && validationResultTab7;
        } else {
            return true;
        }
    },
    loadNextTab: function() {
        var currentTabID = BFActivityOption.getCurrentTabID();
        if (currentTabID != null) {
            var nextTabID = BFActivityOption.getNextTabID(currentTabID);
            if (nextTabID != null) {
                if (this.validateTab(currentTabID) == true) {
                    var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    while (nextTabID != null) {
                        this.enableTabHeader(nextTabID);
                        if (this.isTabCompleted(nextTabID) == true) {
                            nextTabID = BFActivityOption.getNextTabID(nextTabID);
                        } else {
                            break;
                        }
                    }
                    nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    $('#' + CMSUtility.getAnchorID(nextTabID)).click();
                } else {
                    var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    while (nextTabID != null) {
                        if (nextTabID != 'tab9') {
                            this.disableTabHeader(nextTabID);
                            nextTabID = BFActivityOption.getNextTabID(nextTabID);
                        } else {
                            nextTabID = null;
                        }
                    }
                }
            }
        }
    },
    loadPreviousTab: function() {
        var currentTabID = BFActivityOption.getCurrentTabID();
        if (currentTabID != null) {
            var previousTabID = BFActivityOption.getPreviousTabID(currentTabID);
            while (previousTabID != null) {
                var tab = this.getTab(previousTabID);
                if (tab.disabledHeader == false) {
                    $('#' + CMSUtility.getAnchorID(previousTabID)).click();
                    break;
                } else {
                    previousTabID = BFActivityOption.getPreviousTabID(previousTabID);
                }
            }
        }
    },
    isTabCompleted: function(tabID) {
        var tab = this.getTab(tabID);
        var container = document.getElementById(tabID);
        var fv = hyf.FMAction.getFormValidator();
        var errors = fv.checkContainer(container);

        if (errors.length > 0) {
            tab.completed = false;
        } else {
            tab.completed = true;
        }
        return tab.completed;
    },

    disableTabBasedOnActivityName: function(tabID, activityName) {
        // Disable tab based on BFActivityOption
        var foundActivity = BFActivityOption.actList.filter(function(node, index) {
            return node.name == activityName;
        })
        if (foundActivity.length > 0) {
            var readonlyTab = foundActivity[0].readonly.filter(function(node, index) {
                return node == tabID;
            });

            if (readonlyTab.length > 0) {
                this.disableTab(tabID);
            }
        }
    },

    // This function will be called after each tab is loaded.
    initTabAfterLoad: function(totalTabCount, tabID, activityName) {
        // Disable tab based on BFActivityOption
        // var foundActivity = BFActivityOption.actList.filter(function(node, index) {
        //     return node.name == activityName;
        // })
        // if (foundActivity.length > 0) {
        //     var readonlyTab = foundActivity[0].readonly.filter(function(node, index) {
        //         return node == tabID;
        //     });
        //
        //     if (readonlyTab.length > 0) {
        //         this.disableTab(tabID);
        //     }
        // }
        this.disableTabBasedOnActivityName(tabID, activityName);

        var tab = this.getTab(tabID);
        if (tab.onInit != null) {
            tab.onInit();
        }

        tab.completed = this.isTabCompleted(tabID);

        this.totalLoadedTabCount += 1;
        if (this.totalLoadedTabCount == totalTabCount) {
            this.initTabsAfterAllTabLoaded();
        }
    },
    resetTabs : function() {
        var activeTabID = BFActivityOption.getCurrentTabID();
        hyf.util.setFieldValue('tab_control', activeTabID);

        var activeTabs = BFActivityOption.getActiveTabList(getActivityName());
        var leftTabNotCompleted = false;
        for (var index = 0; index < activeTabs.length; index++) {
            var currentTabCompleted = this.isTabCompleted(activeTabs[index]);
            var previousTabCompleted = (index > 0) ? this.isTabCompleted(activeTabs[index - 1]) : true;

            if (index == 0) {
                this.enableTabHeader(activeTabs[index]);
                document.getElementById(CMSUtility.getAnchorID(activeTabs[index])).className = 'selectedTab';
            } else {
                if (leftTabNotCompleted == true) {
                    if (activeTabs[index] == 'tab9') {
                        this.enableTabHeader(activeTabs[index]);
                    } else {
                        this.disableTabHeader(activeTabs[index]);
                    }

                } else {
                    this.enableTabHeader(activeTabs[index]);
                }
            }
            if (currentTabCompleted == false) {
                leftTabNotCompleted = true;
            }
        }
    },
    enableTabsForModification : function() {
        var activityName = getActivityName();
        var option = BFActivityOption.getCurrentActivityOption(activityName);
        option.readonly = [];

        var currentTabID = BFActivityOption.getCurrentTabID();
        this.enableTab(currentTabID);

        //hyf.util.enableComponent("button_apscm_return_2");
        CMSUtility.disableComponents(["btnApproveClsSpc","btnCancelReq_3", "btnModifyWorksheet"]);

        $('#h_modifyRequested').val('true');
    },
    // This function will be called after all tabs are loaded.
    initTabsAfterAllTabLoaded: function() {
        initMaxSize();
        setDateIconTabOrder();

        $(document).trigger('CMS_ALL_TAB_LOADED');
        console.log('CMS_ALL_TAB_LOADED triggerred.');

        var activityName = getActivityName();
        var tabs = BFActivityOption.getActiveTabList(activityName);

        tabs.forEach(function(tab) {
            TabManager.disableTabBasedOnActivityName(tab, activityName);
        });
        this.resetTabs();

        // keep the current tab selection
        var storedTabID = $("#currentTabID").val();
        if (storedTabID) {
            var tab = TabManager.getTab(storedTabID);
            if (tab.disabledHeader == false) {
                TabManager.tabChanger(storedTabID);
                TabManager.showHidePreNextButtons();

                $('#' + CMSUtility.getAnchorID(storedTabID)).focus();
            }
            $("#currentTabId").val(""); // clear current tab for closing page
        }

        showHideTabsUponRequestType();

        greyOutScreen(false);

        var modificationRequested = $('#h_modifyRequested').val();
        if (modificationRequested == 'true') {
            this.enableTabsForModification();
        }

        var alertMessage = $('#pv_alertMessage').val();
        if (alertMessage != null && alertMessage.length > 0) {
            showAlertMessage(alertMessage);
            $('#pv_alertMessage').val("");
        }
    },
    // This function should be called before loading tabs.
    // This function is to add TabManager.initTabAFterLoad function to each tabs so that inittabAFterLoad can be called.
    initResponseHandler: function(totalTabCount) {
        if (window != null) {
            var activityName = getActivityName();
            this.tabList.forEach(function(tab) {
                window[tab.targetGroup + "ManipulateResponse"] = function(content, flag) {
                    content = content + '<div><script type="text/javascript">function ' + tab.targetGroup +
                        '_processAfterLoad() {TabManager.initTabAfterLoad(' + totalTabCount + ',"' + tab.id + '","' + activityName + '" );};' +
                        'hyf.attachEventHandler(window, "onload",' + tab.targetGroup + '_processAfterLoad);</script></div>';
                    return content;
                }
            });
        } else {
            console.log("STRATCONMAIN - initResponseHandler() - window is null.");
        }
    },

    _currentTab: '',

    // Sometimes webmaker loses _hyfCondDisplayIds property that affects tab behavior.
    // If it is not found, this property should be reinitialized to have the array of numbers from 0 to 8.
    ensureTabControlPropertyPopulated: function() {
        try {
            var hyfCondDisplayIDs = $('#tab_control')[0]._hyfCondDisplayIds;
            if (!hyfCondDisplayIDs) {
                $('#tab_control')[0]._hyfCondDisplayIds = [0, 1, 2, 3, 4, 5, 6, 7, 8];
            } else {
                if (hyfCondDisplayIDs.length <= 0) {
                    $('#tab_control')[0]._hyfCondDisplayIds = [0, 1, 2, 3, 4, 5, 6, 7, 8];
                }
            }
        } catch (e) {
        }
    },

    // This function is called whenever webmaker tab is clicked.
    // WebMaker form has default tabChanger function and this is custom one.
    tabChanger: function(value) {
        if (this._currentTab == value) {
            return;
        };
        _currentTab = value;

        this.ensureTabControlPropertyPopulated();
        this.resetTabs();

        var currentTabID = BFActivityOption.getCurrentTabID();
        var activeTabs = BFActivityOption.getActiveTabList(getActivityName());
        if (this.isTabCompleted(currentTabID) == true) {
            hyf.util.setFieldValue('tab_control', value);
            this.tabList.forEach(function(tab) {
                if (tab.disabledHeader == false) {
                    document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                }
            });

            var requestNumber = $('#h_requestNumber').val();
            if (isReadOnly() == false) {
                if (requestNumber == null || requestNumber.length == 0) {
                    $('#h_now').val(CMSUtility.getNowUTCString());
                    callPartialPage(null, 'getRequestNumber.do', "system", 'layoutForResponse');
                };
            }
            document.getElementById(CMSUtility.getAnchorID(value)).className = 'selectedTab';
        } else {
            if (isReadOnly() == false) {
                var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                while (nextTabID != null) {
                    if (nextTabID != 'tab9') {
                        this.disableTabHeader(nextTabID);
                        nextTabID = BFActivityOption.getNextTabID(nextTabID);
                    } else {
                        hyf.util.setFieldValue('tab_control', value);
                        this.tabList.forEach(function(tab) {
                            if (tab.disabledHeader != true) {
                                document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                            }
                        });
                        document.getElementById(CMSUtility.getAnchorID(value)).className = 'selectedTab';
                        nextTabID = null;
                    }
                }
                // If destination tab is in left side
                if (value < currentTabID) {
                    hyf.util.setFieldValue('tab_control', value);
                    this.tabList.forEach(function(tab) {
                        if (tab.disabledHeader == false) {
                            document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                        }
                    });

                    document.getElementById(CMSUtility.getAnchorID(value)).className = 'selectedTab';
                } else {
                    if (typeof event != 'undefined' && event != null) {
                        event.preventDefault();
                    }
                }
            }
        }

        // Broadcast ON_TAB_CHANGE event.
        // Attachment controller in document tab is using this event to update mandatory document type list.
        $(document).trigger("ON_TAB_CHANGE");
        return false;
    },
    showHidePreNextButtons: function() {
         var selectedTabID = BFActivityOption.getCurrentTabID();
         var activeTabs = BFActivityOption.getActiveTabList();

         var currentTabIndex = 0;
         for (var index = 0; index < activeTabs.length; index++) {
             if (activeTabs[index] == selectedTabID) {
                 currentTabIndex = index;
                 break;
             }
         }

         if (currentTabIndex == 0) {
             hyf.util.disableComponent("button_Previous");
             hyf.util.enableComponent("button_Next");
         } else if (currentTabIndex == activeTabs.length - 1) {
             hyf.util.enableComponent("button_Previous");
             hyf.util.disableComponent("button_Next");
         } else {
             CMSUtility.enableComponents(["button_Previous","button_Next"])
         }
    },
    originalTabChanger: null,
    installCustomTabChanger: function() {
        if (window.tab_controlTabChange != null) {
            this.originalTabChanger = window.tab_controlTabChange;
            window.tab_controlTabChange = function(value) {
                var tab = TabManager.getTab(value);
                if (tab.disabledHeader == false) {
                    TabManager.tabChanger(value);
                    TabManager.showHidePreNextButtons();
                    if (isReadOnly() == false) {
                        enableTabsForSubmission();
                        callPartialPage(null, 'saveTabContent.do', null, 'layoutForResponse2');
                        rollbackTabsAfterSubmission();
                    }
                }
            }
        }
    },
    initTab: function() {
        var activityName = getActivityName();
        var currentActivityOption = BFActivityOption.getCurrentActivityOption(activityName);
        this.initResponseHandler(this.tabList.length);

        this.totalLoadedTabCount = 0;
        this.tabList.forEach(function(tab, index) {
            $('#' + CMSUtility.getAnchorID(tab.id)).attr('tabindex', index + 1);
            if (index == 0) {
                hyf.util.setFieldValue('tab_control', tab.id);
            } else {
                // Enable document tab always
                if (tab.id != 'tab9') {
                    TabManager.disableTabHeader(tab.id);
                }
            }
            setTimeout(TabManager.loadTab(tab.id), 0);
        });

        var firstTab = true;
        // Hide Tabs
        this.tabList.forEach(function(item) {
            var showTabs = currentActivityOption.tabs.filter(function(showTabName, index) {
                return showTabName == item.id;
            })
            if (showTabs.length == 0) {
                TabManager.hideTabHeader(item.id);
            } else {
                TabManager.showTabHeader(item.id);
                if (firstTab == true) {
                    firstTab = false;
                    document.getElementById(CMSUtility.getAnchorID(item.id)).className = 'selectedTab';
                    if (item.id != 'tab1') {
                        document.getElementById(CMSUtility.getAnchorID('tab1')).className = 'unselectedTab';
                    }
                    //$('#' + CMSUtility.getAnchorID(item.id)).click();
                } else {
                    document.getElementById(CMSUtility.getAnchorID(item.id)).className = 'unselectedTab';
                }
            }
        });

        $(".tabContainer a").off("click").click(function(e) {
            e.preventDefault();
            TabManager.loadTabFromAnchor(this);
        });
        $('#button_Previous').off("click").click(function() {
            TabManager.loadPreviousTab();
        });
        $('#button_Next').off("click").click(function() {
            TabManager.loadNextTab();
        });
    },

    tabList: [{
        id: "tab1",
        targetUrl: "/StratConMain/General.do",
        targetGroup: "partial_tab1",
        name: "General",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            $('#SG_RT_ID').on("change", function() {
                resetRequestType();
            });
            resetRequestType();
        }
    }, {
        id: "tab2",
        targetUrl: "/StratConMain/Position.do",
        targetGroup: "partial_tab2",
        name: "Position",
        loaded: false,
        completed: false,
        disabledHeader: false
    }, {
        id: "tab3",
        targetUrl: "/StratConMain/Meeting.do",
        targetGroup: "partial_tab3",
        name: "Meeting",
        loaded: false,
        completed: false,
        disabledHeader: false,
        eventHandler: {
            event_change_sshMeetingSchedDT: function() {
                if (isReadOnly() == false) {
                    var meetingDate = $('#SSH_MEETING_SCHED_DT').val();
                    if (meetingDate == null || meetingDate.length == 0) {
                        CMSUtility.disableComponents(["button_cr_notify_2"])
                    } else {
                        CMSUtility.enableComponents(["button_cr_notify_2"])
                    }
                } else {
                    CMSUtility.disableComponents(["button_cr_notify_2"])
                }
            }
        },
        onInit: function() {
            CMSUtility.disableComponents(["button_mr_notify_2","button_escr_notify_2"]);
            var activityName = getActivityName();
            if (activityName == 'Modify Request' || activityName == 'Hold Strategic Consultation Meeting') {
                $(document).on("MEETING_DATE_CHANGED", function() {
                    var isMeetingDateChanged = $('#MEETING_DATE_CHANGED').val();
                    if (isMeetingDateChanged == 'true') {
                        CMSUtility.enableComponents(["button_mr_notify_2","button_escr_notify_2"])
                        CMSUtility.disableComponents(['button_SaveWorkitem_2','button_escr_send_2']);
                    } else {
                        CMSUtility.disableComponents(["button_mr_notify_2","button_escr_notify_2"])
                        CMSUtility.enableComponents(['button_SaveWorkitem_2','button_escr_send_2']);
                    }
                });
            }

            $('#SSH_MEETING_SCHED_DT').change(function() {
                TabManager.tabList[2].eventHandler.event_change_sshMeetingSchedDT();
            });
            TabManager.tabList[2].eventHandler.event_change_sshMeetingSchedDT();
        }
    }, {
        id: "tab4",
        targetUrl: "/StratConMain/showAoc.do",
        targetGroup: "partial_tab4",
        name: "Area of Cons.",
        loaded: false,
        completed: false,
        disabledHeader: false
    }, {
        id: "tab5",
        targetUrl: "/StratConMain/showSmeJa.do",
        targetGroup: "partial_tab5",
        name: "SME/Job Analysis",
        loaded: false,
        completed: false,
        disabledHeader: false
    }, {
        id: "tab6",
        targetUrl: "/StratConMain/showRi.do",
        targetGroup: "partial_tab6",
        name: "Incentives",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            $('#RI_OA_APRV_ITEM').change(function() {
                $(document).trigger('ON_DOCUMENT_CHANGE');
            })
        }
    }, {
        id: "tab7",
        targetUrl: "/StratConMain/showTr.do",
        targetGroup: "partial_tab7",
        name: "Outreach",
        loaded: false,
        completed: false,
        disabledHeader: false
    }, {
        id: "tab8",
        targetUrl: "/StratConMain/showApr.do",
        targetGroup: "partial_tab8",
        name: "Approvals",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            $(document).on('CMS_CON_APR_INIT_COMPLETED', function() {
                var onChange_IS_SO_ACK = function() {
                    var isSOConfirmed = $('#IS_SO_ACK').prop("checked");
                    if (isSOConfirmed == true) {
                        CMSUtility.disableComponents(["button_acscm_return_2", "button_CancelWorkitem"]);
                    } else {
                        CMSUtility.enableComponents(["button_acscm_return_2", "button_CancelWorkitem"]);
                    }
                }
                var onChange_IS_HR_CLS_SPC_APR = function() {
                    var isConfirmed = $('#IS_HR_CLS_SPC_APR').prop("checked");
                    if (isConfirmed == true) {
                        CMSUtility.disableComponents(["button_apscm_return_2", "button_CancelWorkitem", "button_apscm_enabletabs"]);
                    } else {
                        CMSUtility.enableComponents(["button_apscm_return_2", "button_CancelWorkitem", "button_apscm_enabletabs"])
                    }
                }
                var onChange_IS_HR_STF_SPC_APR = function() {
                    var isConfirmed = $('#IS_HR_STF_SPC_APR').prop("checked");
                    if (isConfirmed == true) {
                        CMSUtility.disableComponents(["button_apscm_return_2","button_CancelWorkitem","button_apscm_enabletabs"]);
                    } else {
                        CMSUtility.enableComponents(["button_apscm_return_2","button_CancelWorkitem","button_apscm_enabletabs"])
                    }
                }

                $('#IS_SO_ACK').change(onChange_IS_SO_ACK);
                $('#IS_HR_CLS_SPC_APR').change(onChange_IS_HR_CLS_SPC_APR);
                $('#IS_HR_STF_SPC_APR').change(onChange_IS_HR_STF_SPC_APR);

                var isSODisabled = $('#IS_SO_ACK').attr('disabled');
                if (isSODisabled != 'disabled') {
                    onChange_IS_SO_ACK();
                }
                var isClassDisabled = $('#IS_HR_CLS_SPC_APR').attr('disabled');
                if (isClassDisabled != 'disabled') {
                    onChange_IS_HR_CLS_SPC_APR();
                }

                var isStaffDisabled = $('#IS_HR_STF_SPC_APR').attr('disabled');
                if (isStaffDisabled != 'disabled') {
                    onChange_IS_HR_STF_SPC_APR();
                }
            });
        },
        enableHandler: null,
    }, {
        id: "tab9",
        targetUrl: "/cmscommon/showAttachment.do",
        targetGroup: "partial_tab9",
        name: "Documents",
        loaded: false,
        completed: false,
        disabledHeader: false
    }]
};

// UserGroup {
//      Name: GroupName,
//      ID: 0000000101,
//      Path: /root/GroupName }
var _CMS_myUserGroups = null;
function isCurrentUserMemberOf(userGroupName) {
    if (userGroupName == null || userGroupName.length == 0) {
        console.log("STRATCONMAIN - isCurrentUserMemberOf() - userGroupName is null or empty.");
    }
    if (_CMS_myUserGroups == null) {
        var rawMyUserGroups = getCurrentUserGroupData();
        if (rawMyUserGroups != null && rawMyUserGroups.length > 0) {
            var x2js = new X2JS();
            _CMS_myUserGroups = x2js.xml_str2json(rawMyUserGroups);
            x2js = null;
        } else {
            _CMS_myUserGroups = {UserGroups: {}};
        }
    }

    if (_CMS_myUserGroups != null && _CMS_myUserGroups.UserGroups != null && _CMS_myUserGroups.UserGroups.UserGroup != null) {
        var foundGroups = _CMS_myUserGroups.UserGroups.UserGroup.filter(function(node, index) {
            return node.Name == userGroupName
        });
        return foundGroups.length > 0;
    } else {
        return false;
    }
}

// Request Type in General Tab
function resetRequestType() {
    var requestType = {
        label: $('#SG_RT_ID option:selected').text(),
        value: $('#SG_RT_ID option:selected').val()
    };

    if (requestType.value != '') {
        $('#requestType').text(requestType.label);
    } else {
        $('#requestType').text('');
    }

    // var actOption = BFActivityOption.getCurrentActivityOption(getActivityName());
    // var foundTabs = actOption.tabs.filter(function(tab, index) {
    //     return tab == 'tab4' || tab == 'tab7' || tab == 'tab5';
    // });
    //
    // foundTabs.forEach(function(tab) {
    //     if (tab == 'tab4' || tab == 'tab5' || tab == 'tab7') {
    //         BFActivityOption.addTabToCurrentActivity(getActivityName(), tab);
    //         TabManager.showTabHeader(tab);
    //     }
    // })
    //
    // var foundActiveTabs = BFActivityOption.getActiveTabList(getActivityName()).filter(function(tab, index) {
    //     return tab == 'tab4' || tab == 'tab7' || tab == 'tab5';
    // });
    //
    // if ("Classification Only" == requestType.label) {
    //     foundActiveTabs.forEach(function(tab) {
    //         if (tab == 'tab4') {
    //             TabManager.hideTabHeader(tab);
    //             BFActivityOption.removeTabFromCurrentActivity(getActivityName(), tab);
    //         }
    //     })
    // } else if ("Appointment" == requestType.label) {
    //     foundActiveTabs.forEach(function(tab) {
    //         if (tab == 'tab5' || tab == 'tab7') {
    //             TabManager.hideTabHeader(tab);
    //             BFActivityOption.removeTabFromCurrentActivity(getActivityName(), tab);
    //         }
    //     })
    // }

    TabManager.resetTabs();
}

function enableTab(tabID) {
    var disabledComponents = $('#' + tabID + ' input[readonly], input[disabled], select[disabled], textarea[disabled]');
    $.each(disabledComponents, function(index, component) {
        var disabledAttribute = $(this).attr('disabled');
        var readOnlyAttribute = $(this).attr('readonly');

        if (disabledAttribute) {
            $(this).removeAttr('disabled');
            $(this).attr('orgDisabled','disabled');
        }
        if (readOnlyAttribute) {
            $(this).removeAttr('readonly');
            $(this).attr('orgReadonly', 'readonly');
        }
    });
}

function enableTabsForSubmission() {
    var activeTabs = BFActivityOption.getActiveTabList(getActivityName());
    activeTabs.forEach(function(tab) {
        //TabManager.enableTab(tab);
        enableTab(tab);
    })

    // TabManager.enableTab
    //
    // hyf.util.enableComponent(tabID);
    // $('#' + tabID + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').show();
    //
    // if (tabID == 'tab8') {
    //     stratconApr_rollbackHandler();
    // }
}

function rollbackTabsAfterSubmission() {
    var targetComponents = $('input[orgDisabled], input[orgReadonly], select[orgDisabled], select[orgReadonly], textarea[orgDisabled], textarea[orgReadonly]');
    $.each(targetComponents, function(index, component) {
        var orgDisabled = $(this).attr('orgDisabled');
        var orgReadonly = $(this).attr('orgReadonly');

        if (orgDisabled) {
            $(this).attr('disabled', true);
            $(this).removeAttr('orgDisabled');
        }
        if (orgReadonly) {
            $(this).attr('readonly', true);
            $(this).removeAttr('orgReadonly');
        }
    });
}

function addButtonHandler(buttonID, validationRequired, buttonOptions, confirmMessage) {
    if (buttonID != null && buttonOptions != null) {
        $('#' + buttonID).off('click').click(function() {
            if (validationRequired == true) {
                var allTabCompleted = true;
                var activeTabs = BFActivityOption.getActiveTabList(getActivityName());
                for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                    var validated = TabManager.validateTab(activeTabs[tabIndex]);
                    if (validated == false) {
                        return;
                    }
                }

                var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
                if (mandatoryDocumentsValid != 'true') {
                    TabManager.enableTabHeader('tab9');
                    TabManager.enableTab('tab9');
                    $('#' + CMSUtility.getAnchorID('tab9')).click();
                    bootbox.alert("Please upload the missing required document(s).");
                    return;
                }
            }

            if (confirmMessage != null && confirmMessage.length > 0) {
                bootbox.dialog({
                        message: '<p class="bootbox-body">' + confirmMessage + '</p>',
                        onEscape: true,
                        buttons: [{
                            label: 'Yes',
                            className: 'btn-success',
                            callback: function() {
                                buttonOptions.forEach(function(option) {
                                    if (option.id == 'pv_requestStatusDate') {
                                        option.value = CMSUtility.getNowUTCString();
                                    }
                                    $('#' + option.id).val(option.value);
                                })
                                greyOutScreen(true);
                                enableTabsForSubmission();
                                submitFormPage(buttonID, "saveNewForm");
                            }
                        }, {
                            label: 'No',
                            className: 'btn-danger'
                        }]
                    });
            } else {
                buttonOptions.forEach(function(option) {
                    if (option.id == 'pv_requestStatusDate') {
                        option.value = CMSUtility.getNowUTCString();
                    }
                    $('#' + option.id).val(option.value);
                })
                greyOutScreen(true);
                enableTabsForSubmission();
                submitFormPage(buttonID, "saveNewForm");
            }
        });
    } else {
        console.log("STRATCONMAIN - addButtonHandler() - buttonID or buttonOption is null.");
    }
}

function initLayoutPerActivity() {
    if (isReadOnly() == true) {
        $('#bottomSection').hide();
        return;
    }

    // $('#button_SaveWorkitem_2').on('click', function() {
    //     $('#WIH_save_requested').val('true');
    //     $("#currentTabID").val(BFActivityOption.getCurrentTabID()); // store current tabid to reset after page reload
    //     greyOutScreen(true);
    //     enableTabsForSubmission();
    //     submitFormPage('button_SaveWorkitem_2', "saveNewForm");
    // });

    var activityName = getActivityName();
    if (activityName == "Create Request") {
        if (isCurrentUserMemberOf('Selecting Officials') == true) {
            $('#button_cr_send_2').hide();
            addButtonHandler('button_cr_notify_2', true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, {
                id: 'pv_requestStatus', value: 'Request Created'
            }, {
                id: 'pv_requestStatusDate', value: ''   // Value will be set inside of addButtonHandler function.
            }, {
                id: 'pv_selectOfficialReviewReq', value: 'No'
            }]);
        } else {
            $('#button_cr_notify_2').hide();
            addButtonHandler('button_cr_send_2', true, [{
                id: 'WIH_complete_requested', value: 'true'
            }, {
                id: 'pv_requestStatus', value: 'Request Created'
            }, {
                id: 'pv_requestStatusDate', value: ''
            }, {
                id: 'pv_selectOfficialReviewReq', value: 'Yes'
            }]);
        }
        $('#actionButton_CreateRequest_2').removeClass('hide');
    } else if (activityName == "Review Request") {
        addButtonHandler('button_rr_notify_2', true, [{
            id: 'WIH_complete_requested', value: 'true'
        }, {
            id: 'pv_requestStatusDate', value: ''
        }]);
        $('#actionButton_ReviewRequest_2').removeClass('hide');
    } else if (activityName == "Modify Request") {
        addButtonHandler('button_mr_notify_2', true, [{
            id: 'WIH_complete_requested', value: 'true'
        }, {
            id: 'pv_requestStatusDate', value: ''
        }]);
        $('#actionButton_ModifyRequest_2').removeClass('hide');
        $('#button_SaveWorkitem_2').hide();
    } else if (activityName == "Hold Strategic Consultation Meeting") {
        addButtonHandler('button_escr_notify_2', true, [{
            id: 'WIH_complete_requested', value: 'true'
        }, {
            id: 'pv_meetingResched', value: 'Yes'
        }]);
        // Enabled when the all mandatory fields are completed
        addButtonHandler('button_escr_send_2', true, [{
            id: 'WIH_complete_requested', value: 'true'
        }, {
            id: 'pv_meetingResched', value: 'No'
        }, {
            id: 'pv_requestStatus', value: 'Consult Meeting Conducted'
        }, {
            id: 'pv_requestStatusDate', value: ''
        }]);
        $('#actionButton_ESCR_2').removeClass('hide');
    } else if (activityName == "Acknowledge Strat Cons Meeting") {
        addButtonHandler('button_acscm_approval_2', true, [{
            id: 'WIH_complete_requested', value: 'true'
        }, {
            id: 'pv_meetingAckResponse', value: 'Yes'
        }], "Are you sure you want to submit your concurrence with the worksheet?");

        $('#button_acscm_return_2').off("click").click(function() {
            sendBackForModification();
        })

        $('#actionButton_ACSCM_2').removeClass('hide');
    } else if (activityName == "Approve Strat Cons Meeting") {
        hyf.util.disableComponent("button_apscm_return_2");
        addButtonHandler('button_apscm_approval_2', true, [{
            id: 'WIH_complete_requested', value: 'true'
        }, {
            id: 'pv_meetingApvResponse', value: 'Yes'
        }], "Are you sure you want to submit your approval of the worksheet?");

        $('#button_apscm_return_2').off("click").click(function() {
            sendBackForModification();
        });

        $('#button_apscm_enabletabs').off("click").click(function() {
            popupModifyRequest();
        });

        $('#actionButton_APSCM_2').removeClass('hide');
    } else {
        console.log("STRATCONMAIN - initLayoutPerActivity() - No activity name matched [" + activityName + "]");
    }

    $('#button_CancelWorkitem').off('click').click(function() {
        //openCancelRequestDialog();
        popupCancellation();
    });
};

//
// Form Cell Raw API
//
var _activityName = null;
function getActivityName() {
    if (_activityName == null) {
        _activityName = $('#h_activityName').attr('value');
        if (_activityName == null || _activityName.length == 0) {
            console.log("STRATCONMAIN - getActivityName() - ActivityName is null or empty.")
        }
    }
    return _activityName;
}

var _readOnly = null;
function isReadOnly() {
    if (_readOnly == null) {
        _readOnly = $('#h_readOnly').val();
        if (_readOnly == 'y') {
            _readOnly = true;
        } else {
            _readOnly = false;
        }
    }
    return _readOnly;
}

var _currentUserGroupData = null;
function getCurrentUserGroupData() {
    if (_currentUserGroupData == null) {
        _currentUserGroupData = $('#h_userGroups').val();
        if (_currentUserGroupData == null || _currentUserGroupData.length == 0) {
            console.log("STRATCONMAIN - getCurrentUserGroupData() - ActivityName is null or empty.")
        } else {
            $('#h_userGroups').val('');
        }
    }
    return _currentUserGroupData;
}

// This function will be called after getRequestNumber.do is completed.
function resetRequestNumber() {
    var requestNumber = $('#h_response_requestNumber').val();

    $('#h_requestNumber').val(requestNumber);
    $('#pv_requestStatus').val('Request Created');
    $('#requestNumber').text(requestNumber);
    $('#output_requestStatus').text('Request Created');
    var requestedStatusDate = $('#h_now').val();
    $('#pv_requestStatusDate').val(requestedStatusDate);
}

function popupModifyRequest() {
    bootbox.dialog({
        message: "Are you sure you want to modify worksheet?",
        onEscape: true,
        buttons: [{
            label: 'Yes',
            className: 'btn-success',
            callback: function() {
                var tabs = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'];
                tabs.forEach(function(tab) {
                    TabManager.enableTab(tab);
                })

                // var tabID = 'tab1';
                // var tabCount = 0;
                // TabManager.enableTab(tabID);
                // tabID = BFActivityOption.getNextTabID(tabID)
                // while(tabID != null && tabCount <= 9) {
                //     TabManager.enableTab(tabID);
                //     tabID = BFActivityOption.getNextTabID(tabID);
                //     tabCount++;
                // };

                var activityName = getActivityName();
                var option = BFActivityOption.getCurrentActivityOption(activityName);
                option.readonly = [];

                hyf.util.enableComponent("button_apscm_return_2");
                CMSUtility.disableComponents(["button_apscm_enabletabs","IS_SO_ACK","IS_HR_CLS_SPC_APR","IS_HR_STF_SPC_APR","button_apscm_approval_2","button_CancelWorkitem"])
            }
        }, {
            label: 'No',
            className: 'btn-danger'
        }]
    });
}

function popupCancellation() {
    var isUserSO = isCurrentUserMemberOf('Selecting Officials');
    var isUserLiaison = isCurrentUserMemberOf('HR Liaison');
    var isXO = isCurrentUserMemberOf('Executive Officers');
    var isClassificationSpecialist = isCurrentUserMemberOf('HR Classification Specialists');
    var isStaffingSpecialist = isCurrentUserMemberOf('HR Staffing Specialists');

    var reasons = [];

    if (isUserSO == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[Selecting Officials]/CancellationReason');
    } else if (isUserLiaison == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[HR Liaison]/CancellationReason');
    } else if (isXO == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[Executive Officers]/CancellationReason');
    } else if (isClassificationSpecialist == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[HR Classification Specialists]/CancellationReason');
    } else if (isStaffingSpecialist == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[HR Staffing Specialists]/CancellationReason');
    } else {
        reasons = LookupManager.findByLTYPE('UserGroup[Default]/CancellationReason');
    }

    var options = '<option value>Select one</option>';
    reasons.forEach(function(reason) {
        options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
    });

    var dialog = bootbox.dialog({
        title: 'Reason for Cancellation',
        message: '<span>Cancellation Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span><span>:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
        onEscape: true,
        buttons: {
            confirm: {
                label: 'OK',
                className: 'btn-success',
                callback: function() {
                    var message = $('div.bootbox select option:selected').text();
                    if (message == null || message.length == 0) {
                        return false;
                    }

                    setTimeout(function() {
                        greyOutScreen(true);
                        enableTabsForSubmission();
                        $('#WIH_complete_requested').val('true');
                        $('#pv_requestStatus').val('Request Cancelled');
                        $('#pv_requestStatusDate').val(CMSUtility.getNowUTCString());
                        $('#pv_CancelReason').val(message);
                        submitFormPage('button_CancelWorkitem', "saveNewForm");
                    }, 0);
                }
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-danger'
            }
        }
    });

    $('div.bootbox button.btn-success').prop('disabled', true);

    $('div.bootbox select').on("change keyup", function() {
        var message = $('div.bootbox select option:selected').val();
        if (message == "") {
            $('div.bootbox button.btn-success').prop('disabled', true);
        } else {
            $('div.bootbox button.btn-success').prop('disabled', false);
        }
    });
}

function showAlertMessage(message) {
    var dialog = bootbox.dialog({
        title: 'Requested Changes',
        message: '<textarea disabled rows="5" class="bootbox-input bootbox-input-text form-control">' + message + '</textarea>',
        onEscape: true,
        buttons: {
            confirm: {
                label: 'OK',
                className: 'btn-success',
            }
        }
    });
}

function sendBackForModification() {
    var dialog = bootbox.dialog({
        title: 'Provide a summary of your changes',
        message: '<textarea rows="5" class="bootbox-input bootbox-input-text form-control"></textarea>',
        onEscape: true,
        buttons: {
            confirm: {
                label: 'OK',
                className: 'btn-success',
                callback: function() {
                    var message = $('div.bootbox textarea').val();
                    if (message != null && message.length > 0) {
                        setTimeout(function() {
                            $('#WIH_complete_requested').val('true');
                            if (getActivityName() == 'Acknowledge Strat Cons Meeting') {
                                $('#pv_meetingApvResponse').val('No');
                                $('#pv_worksheetFeedbackSelectOfficial').val(message);
                                $('#pv_alertMessage').val(message);
                            } else {
                                if (isCurrentUserMemberOf('HR Classification Specialists') == true) {
                                    $('#pv_returnToSOFromClassSpec').val('Yes');
                                    $('#pv_worksheetFeedbackClassSpec').val(message);
                                    $('#pv_alertMessage').val(message);
                                } if (isCurrentUserMemberOf('HR Staffing Specialists') == true ) {
                                    $('#pv_returnToSOFromStaffSpec').val('Yes');
                                    $('#pv_worksheetFeedbackStaffSpec').val(message);
                                    $('#pv_alertMessage').val(message);
                                }
                            }
                            greyOutScreen(true);
                            enableTabsForSubmission();
                            submitFormPage('button_apscm_return_2', "saveNewForm");
                        }, 0);
                    } else {
                        return false;
                    }
                }
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-danger'
            }
        }
    });

    $('div.bootbox button.btn-success').prop("disabled", true);

    $('div.bootbox textarea').on("change keyup paste", function() {
        var message = $(this).val();
        if (message.length > 500) {
            $(this).val(message.substring(0, 500));
        }

        if (message.length == 0) {
            $('div.bootbox button.btn-success').prop("disabled", true);
        } else {
            $('div.bootbox button.btn-success').prop("disabled", false);
        }
    });
}

function initMaxSize() {
    var inputControls = $('input[size]');
    $.each(inputControls, function(index, control) {
        var maxSize = $(control).attr('size');
        var id = $(control).attr('id');
        var controlType = $(control).attr('_type');
        var readOnlyAttribute = $(control).attr('readonly');
        var disabledAttribute = $(control).attr('disabled');

        // Skip if the control is date control
        if (controlType != 'date' && typeof id != 'undefined' && !readOnlyAttribute && !disabledAttribute) {
            if ($(control).parent().length == 1
                && $(control).parent().parent().length == 1
                && $(control).parent().parent().parent().length == 1) {
                var initialMessage = $(control).val();

                var target;
                if ($(control).hasClass('dijitInputInner')) {
                    target = $(control).parent().parent().parent();
                } else {
                    target = $(control).parent().parent();
                }

                target.append('<p id="' + (id + '_sizeLabel' ) + '" class="sizeLabel" debugMessage="' + initialMessage + '">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');

                $('#' + id + '_sizeLabel').hide();

                $(control).on('focus', function() {
                    $('#' + id + '_sizeLabel').show();
                });

                $(control).on('blur', function() {
                    $('#' + id + '_sizeLabel').hide();
                });

                $(control).on('keyup paste blur change', function() {
                    var message = $(control).val();
                    if (message.length > maxSize) {
                        $(control).val(message.substring(0, maxSize));
                    }
                    $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
                })
            }
        }
    });

    var inputControls = $('textarea.textbox[maxlength]');
    $.each(inputControls, function(index, control) {
        var maxSize = $(control).attr('maxlength');
        var id = $(control).attr('id');
        var readOnlyAttribute = $(control).attr('readonly');
        var disabledAttribute = $(control).attr('disabled');

        if ($(control).parent().length == 1 && typeof id != 'undefined' && !readOnlyAttribute && !disabledAttribute) {
            var initialMessage = $(control).val();

            $(control).parent().append('<p id="' + (id + '_sizeLabel' ) + '" class="sizeLabel">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');

            $('#' + id + '_sizeLabel').hide();

            $(control).on('focus', function() {
                $('#' + id + '_sizeLabel').show();
            });

            $(control).on('blur', function() {
                $('#' + id + '_sizeLabel').hide();
            });

            $(control).on('keyup keypress blur change', function() {
                var message = $(control).val();
                $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
            })
        }
    });
}

function setDateIconTabOrder() {
    var dateTextBoxes = $('input.textbox[_type=date]');
    $.each(dateTextBoxes, function(index, control) {
        var tabIndex = $(control).attr('tabindex');
        if ($.isNumeric(tabIndex) == true && tabIndex > 0) {
            var controlID = $(control).attr('id');
            var newTabIndex = tabIndex * 1 + 1;
            $('#' + controlID + '_calendar_anchor').attr('tabindex', newTabIndex);
        }
    });
}

function showHideTabsUponRequestType() {
    var activityName = getActivityName();
    var targetTabs = ['tab4', 'tab5', 'tab6', 'tab7'];
    var currentActivityOption = BFActivityOption.getCurrentActivityOption(activityName);

    var requestType = $('#SG_RT_ID :selected').text();
    var classificationType = $('#SG_CT_ID :selected').text();
    if (requestType == 'Appointment') {
        targetTabs.forEach(function(tabID) {
            var foundTabs = currentActivityOption.tabs.filter(function(tab) {
                return tab == tabID;
            });

            if (foundTabs.length > 0) {
                TabManager.clearTabContent(tabID);
                TabManager.hideTabHeader(tabID);
                BFActivityOption.removeTabFromCurrentActivity(activityName, tabID);
            }
        });

        var meetingTabs = currentActivityOption.tabs.filter(function(tab) {
            return tab == 'tab3';
        });

        if (meetingTabs.length > 0) {
            if (classificationType && classificationType.length > 0
                && (classificationType == 'Conduct 5-year Recertification'
                    || classificationType == 'Update Coversheet'
                    || classificationType == 'Review Existing Position Description')) {
                TabManager.clearTabContent('tab3');
                TabManager.hideTabHeader('tab3');
                BFActivityOption.removeTabFromCurrentActivity(activityName, 'tab3');
            } else {
                TabManager.showTabHeader('tab3');
                BFActivityOption.addTabToCurrentActivity(activityName, 'tab3');
            }
        }
    } else {
        if (requestType == 'Classification Only') {
            // Tab4 should be hidden
            TabManager.clearTabContent('tab4');
            TabManager.hideTabHeader('tab4');
            BFActivityOption.removeTabFromCurrentActivity(activityName, 'tab4');
            targetTabs = ['tab5', 'tab6', 'tab7'];
        }

        targetTabs.forEach(function(tabID) {
            var foundTabs = currentActivityOption.tabs.filter(function(tab) {
                return tab == tabID;
            });

            if (foundTabs.length > 0) {
                TabManager.showTabHeader(tabID);
                BFActivityOption.addTabToCurrentActivity(activityName, tabID);
            }
        });
    }
}

//
// StratconMain ENTRY POINT
//
// Form Initialization function
// This function will be called when the mainform is loaded.
function initStratConMainForm() {
    // Following should be called to reduce redundant network traffic.
    getCurrentUserGroupData();

    if (isReadOnly() == true) {
        var activityName = getActivityName();
        var option = BFActivityOption.getCurrentActivityOption(activityName);
        option.readonly = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'];
        // var currentTabID = BFActivityOption.getCurrentTabID();
        // TabManager.disableTab(currentTabID);
    }

    LookupManager.init();
    //CMSUtility.restoreBizFlowParameter();
    TabManager.installCustomTabChanger();
    TabManager.initTab();

    // Request Date
    var requestedDateString = $('#h_creationdate').val();
    if (requestedDateString != null && requestedDateString.length > 0) {
        var requestedDate = new Date(requestedDateString);  // requestedDateString is GMT
        var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
        var requestedDateLabel = CMSUtility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, newDate);
        $('#initiatedDate').text(requestedDateLabel);
    }

    // Request Number
    var requestNumber = $('#h_requestNumber').val();
    $('#requestNumber').text(requestNumber);

    // Request Status
    var requestStatus = $('#pv_requestStatus').val();
    $('#output_requestStatus').text(requestStatus);

    hyf.util.disableComponent("button_Previous");
    hyf.util.enableComponent("button_Next");

    initLayoutPerActivity();

	// set focus on the current tab
	$("a.selectedTab").focus();
}
