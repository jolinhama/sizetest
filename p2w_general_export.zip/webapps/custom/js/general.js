/* global $ FormState StateAction */
/* eslint camelcase: 0, no-unused-vars:0 */

var p2wGen = {
    renderer: function () {
		this.validationJustify('STF_VAL');
        this.validationJustify('PBMS_CON');
        this.validationJustify('HIRE_GUIDE_REV');
        this.searchComChair('HM_ID');
    },
    validationJustify: function(id)
    {
        var fldFrmState = FormState.getState(id);
        var justId = id + '_JUST';        
        if (fldFrmState && fldFrmState.dirty === true) {
            if(fldFrmState.value === 'Y'){
                $('#'+justId).attr('_required','false').addClass('hidden');
                $('#'+justId + '_label').addClass('hidden');
                FormState.doAction(StateAction.changeText(justId, ''), false);
            }else{
                $('#'+justId).attr('_required','true').removeClass('hidden');
                $('#'+justId + '_label').removeClass('hidden');
            }
        }
    },    
    // Init function/method called from On PageLoad; performs
    // various activities to setup the page UI, hide/show fields
    init: function () {
        var base_url = '/bizflowwebmaker/p2w_ajax/'
        //this.setACAutoComplete(base_url);
        this.setAutoComplete('group_general',base_url); 
        $('#SMEInfoGrid').on('click', 'input:radio',this.manageSMEs);
    },
    ajaxCallXML: function(ajaxUrl){
        return $.ajax({ dataType: 'xml', method: 'GET', url: ajaxUrl, cache: 'false' });
    },
    searchComChair: function(id) {
        var fldFrmState = FormState.getState(id);
        var rowCnt = 0;
        if (fldFrmState && fldFrmState.value != 3) {
            FormState.doAction(StateAction.changeText('SCC_NAME',''),false);
            FormState.doAction(StateAction.changeText('SCC_EMAIL',''),false);
            FormState.doAction(StateAction.changeText('SCC_ORG',''),false);
            $('#SMEInfoGrid tr').each(function() {
                rowCnt = ++rowCnt;
                if (rowCnt < 3) {
                    $(this).addClass('hidden');
                }
            });
        } else {
            $('#SMEInfoGrid tr').each(function() {
                rowCnt = ++rowCnt;
                if (rowCnt < 3) {
                    $(this).removeClass('hidden');
                }
            });
        }

    },
    manageSMEs: function() {
        var fldName = $(this).attr('name'); //FormState
        var rowCnt = 0;
        if (fldName === 'SME_REQ') {
            if ($(this).val() === 'Y') {
                $('#SMEInfoGrid tr').each(function() {
                    $(this).removeClass('hidden');
                });
            } else {

                $('#SMEInfoGrid input:text').each(function() {
                    FormState.doAction(StateAction.changeText($(this).attr('id'), ''), false);
                });
                $('#SMEInfoGrid tr').each(function() {
                    rowCnt = ++rowCnt;
                    if (rowCnt > 4) {
                        $(this).addClass('hidden');
                    }
                });
            }
        } else if (fldName) {
            var fldId = $(this).data('fldid');
            var rowNum = fldId.slice(-1);
            if ($(this).val() === 'N') {
                $('#' + fldId).autocomplete('destroy');
                $('#SME_EMAIL_' + rowNum).attr("readonly", false);
                $('#SME_ORG_' + rowNum).attr("readonly", false);
            } else if (!$('#' + fldId).data('autocomplete')) {
                var base_url = '/bizflowwebmaker/p2w_ajax/';
                p2wGen.setAutoComplete(fldId + '_container', base_url);
                $('SME_EMAIL_' + rowNum).attr("readonly", true);
                $('#SME_ORG_' + rowNum).attr("readonly", true);
            }
        }
    },
    setAutoComplete: function(container_id, base_url){
        $('#' + container_id + ' input.js-autocomplete').each(function () {
            var control = $(this);
            var searchUrl = base_url;
            if ($(this).data("autocompleteurl")) {
                searchUrl += $(this).data("autocompleteurl");
            }
            if (!searchUrl || searchUrl.trim() === "") {
                return;
            }
            var labelKeys;
            if ($(this).data("autocompletelabels")) {
                labelKeys = $(this).data("autocompletelabels");
            } else {
                labelKeys = $(this).data("autocompletelabel");
            }
            if (!labelKeys || labelKeys.trim() === "") {
                labelKeys = "label";
            }
            var labelKeysArray = labelKeys.split(',');
            var valueKey = $(this).data("autocompletevaluename");
            if (!valueKey || valueKey.trim() === "") {
                valueKey = "value";
            }
            var otherKeys = $(this).data("autocompleteothers");
            var otherKeysArray = [];
            if (otherKeys && otherKeys.trim() !== "") {
                otherKeysArray = otherKeys.split(',');
            }
            control.autocomplete({
                source: function (request, response) {
                    p2wGen.ajaxCallXML(searchUrl + request.term)
                        .done(function (data) {
                            var dataFromApi = $('record', data).map(function () {
                                
                                    return {
                                        MID: $( "MID", this ).text(),
                                        DSPNAME: $('DSPNAME', this).text(),
                                        DEPTNAME: $('DEPTNAME', this).text(),
                                        EMAIL: $('EMAIL', this).text(),
                                        AC_ADMIN_CD: $( "AC_ADMIN_CD", this ).text(),
                                        AC_ADMIN_CD_DESCR: $('AC_ADMIN_CD_DESCR', this).text()
                                    };
                                
                                
                                }).get();
                        
                            response($.map(dataFromApi, function (item) {
                                if (otherKeys) {
                                    for (var i = 0; i < otherKeysArray.length; i++) {
                                        var otherControlId = otherKeysArray[i].split(':')[0].trim();
                                        if ($('#' + otherControlId)[0]) {
                                            FormState.doAction(StateAction.changeText(otherControlId, ''), false);
                                        }
                                    }
                                }
                                var labelData = "";
                                for (var i = 0; i < labelKeysArray.length; i++) {
                                    labelData += item[labelKeysArray[i].trim()] && item[labelKeysArray[i].trim()].trim() !== "" ? (item[labelKeysArray[i].trim()].trim() + ' | ') : "";
                                }
                                labelData = labelData.substr(0, (labelData.length - 3));
                                var valueData = item[valueKey.trim()];
                                var returnData = {
                                    label: labelData,
                                    value: valueData,
                                };
                                for (var i = 0; i < otherKeysArray.length; i++) {
                                    var otherControlKey = otherKeysArray[i].split(':')[0].trim();
                                    var otherControlValueKey = otherKeysArray[i].split(':')[otherKeysArray[i].split(':').length - 1].trim();
                                    if (item[otherControlValueKey]) {
                                        returnData[otherControlKey] = item[otherControlValueKey];
                                    }
                                }
                                return returnData;
                            }));
                        })
                },
                minLength: 2,
                select: function (event, ui) {
                    for (var i = 0; i < otherKeysArray.length; i++) {
                        var otherControlId = otherKeysArray[i].split(':')[0].trim();
                        var otherControlValueKey = otherKeysArray[i].split(':')[otherKeysArray[i].split(':').length - 1].trim();
                        
                        if ($('#' + otherControlId)[0]) {
                            //Add Check for hidden values and switch type and render based on those
                            console.log(otherControlId);
                            if(otherControlId.search('PART') != -1){
                                FormState.doAction(StateAction.changeValue(otherControlId, '[U]' + ui.item[otherControlId]), false);
                            }else{
                            FormState.doAction(StateAction.changeText(otherControlId, ui.item[otherControlId]), true);
                            }
                        }
                    }
                    FormState.doAction(StateAction.changeText($(this).attr('id'), ui.item['value']), true);
                }
    
            });
        });
    
    }
}